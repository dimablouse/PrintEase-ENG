package com.printease.mobileprinter

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.OpenableColumns
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.print.PrintHelper
import com.google.android.material.button.MaterialButton

class PreviewActivity : AppCompatActivity() {

    private var fileUri: Uri? = null
    private var isPdf = false
    private var fileName = ""

    private lateinit var preview: ImageView
    private lateinit var nameView: TextView
    private lateinit var printBtn: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)

        preview = findViewById(R.id.preview)
        nameView = findViewById(R.id.fileName)
        printBtn = findViewById(R.id.btnPrint)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        printBtn.setOnClickListener { printFile() }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val uri: Uri? = when (i?.action) {
            Intent.ACTION_SEND ->
                if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else
                    @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri == null) {
            toast(getString(R.string.cannot_open))
            finish()
            return
        }
        load(uri)
    }

    private fun resolveType(uri: Uri): String {
        val t = contentResolver.getType(uri)
        if (!t.isNullOrEmpty()) return t
        return if (uri.path?.endsWith(".pdf", ignoreCase = true) == true) "application/pdf" else ""
    }

    private fun load(uri: Uri) {
        val type = resolveType(uri)
        if (type != "application/pdf" && !type.startsWith("image/")) {
            toast(getString(R.string.unsupported))
            finish()
            return
        }
        try {
            var pages = 0
            val bmp: Bitmap
            if (type == "application/pdf") {
                val r = renderPdfFirstPage(uri)
                bmp = r.first
                pages = r.second
            } else {
                bmp = decodeImage(uri)
            }
            fileUri = uri
            isPdf = type == "application/pdf"
            fileName = queryName(uri)
            preview.setImageBitmap(bmp)
            nameView.text =
                if (pages > 0) "$fileName · ${getString(R.string.pages_fmt, pages)}" else fileName
            printBtn.isEnabled = true
        } catch (e: Exception) {
            toast(getString(R.string.cannot_open))
            finish()
        }
    }

    private fun printFile() {
        val uri = fileUri ?: return
        try {
            if (isPdf) {
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                pm.print(fileName, PdfPrintAdapter(this, uri, fileName), PrintAttributes.Builder().build())
            } else {
                PrintHelper(this).apply {
                    scaleMode = PrintHelper.SCALE_MODE_FIT
                }.printBitmap(fileName, uri)
            }
        } catch (e: Exception) {
            toast(getString(R.string.print_failed, e.message ?: ""))
        }
    }

    private fun decodeImage(uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts)!! }
    }

    private fun renderPdfFirstPage(uri: Uri): Pair<Bitmap, Int> {
        val pfd = contentResolver.openFileDescriptor(uri, "r")!!
        pfd.use {
            PdfRenderer(it).use { renderer ->
                val count = renderer.pageCount
                renderer.openPage(0).use { page ->
                    val w = 1000
                    val h = w * page.height / page.width
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return Pair(bmp, count)
                }
            }
        }
    }

    private fun queryName(uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment ?: getString(R.string.doc_default)
        return contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
        } ?: getString(R.string.doc_default)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
