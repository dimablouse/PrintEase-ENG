package com.printease.mobileprinter

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.text.format.Formatter
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private data class Tile(
        val title: Int,
        val icon: Int,
        val color: String,
        val bg: String,
        val action: () -> Unit
    )

    private lateinit var sectionHome: View
    private lateinit var sectionScans: View
    private lateinit var sectionSettings: View
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var scansList: LinearLayout
    private lateinit var scansEmpty: View
    private lateinit var scansScroll: View

    // Keep a reference so the garbage collector does not destroy the WebView before printing finishes
    private var htmlPrintView: WebView? = null

    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { openPreview(it) }
        }

    private val docPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { openPreview(it) }
        }

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val scan = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
                val pdfUri = scan?.pdf?.uri
                if (pdfUri != null) saveScan(pdfUri) else toast(getString(R.string.scan_failed))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(AppConfig.KEY_ONBOARDING_DONE, false)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        sectionHome = findViewById(R.id.sectionHome)
        sectionScans = findViewById(R.id.sectionScans)
        sectionSettings = findViewById(R.id.sectionSettings)
        bottomNav = findViewById(R.id.bottomNav)
        scansList = findViewById(R.id.scansList)
        scansEmpty = findViewById(R.id.scansEmpty)
        scansScroll = findViewById(R.id.scansScroll)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showSection(0)
                R.id.nav_scans -> {
                    showSection(1)
                    refreshScans()
                }
                R.id.nav_settings -> showSection(2)
            }
            true
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (bottomNav.selectedItemId != R.id.nav_home) {
                    bottomNav.selectedItemId = R.id.nav_home
                } else {
                    finish()
                }
            }
        })

        setupHome()
        setupScans()
        setupSettings()
    }

    private fun showSection(i: Int) {
        sectionHome.visibility = if (i == 0) View.VISIBLE else View.GONE
        sectionScans.visibility = if (i == 1) View.VISIBLE else View.GONE
        sectionSettings.visibility = if (i == 2) View.VISIBLE else View.GONE
    }

    // ---------------------------------------------------------------- Home

    private fun setupHome() {
        findViewById<View>(R.id.btnAddPrinter).setOnClickListener { openPrintSettings() }

        val tiles = listOf(
            Tile(R.string.tile_photos, R.drawable.ic_photo, "#F26B38", "#FFF3EE") {
                photoPicker.launch(arrayOf("image/*"))
            },
            Tile(R.string.tile_docs, R.drawable.ic_document, "#1E9BF0", "#EEF6FF") {
                docPicker.launch(arrayOf("application/pdf"))
            },
            Tile(R.string.tile_web, R.drawable.ic_web, "#12A66A", "#EEF9F4") { askUrl() },
            Tile(R.string.tile_email, R.drawable.ic_mail, "#E5383B", "#FFF0F0") { showEmailHelp() },
            Tile(R.string.tile_labels, R.drawable.ic_label, "#F59E0B", "#FFF7E8") { askLabel() },
            Tile(R.string.tile_help, R.drawable.ic_help, "#8B5CF6", "#F5F0FF") { showHelp() }
        )

        val container = findViewById<LinearLayout>(R.id.tilesContainer)
        for (rowTiles in tiles.chunked(3)) {
            val rowView = LinearLayout(this)
            rowView.orientation = LinearLayout.HORIZONTAL
            val rowLp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            rowLp.topMargin = dp(12)
            container.addView(rowView, rowLp)

            for (t in rowTiles) {
                val v = layoutInflater.inflate(R.layout.item_tile, rowView, false)
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                lp.marginStart = dp(6)
                lp.marginEnd = dp(6)
                v.layoutParams = lp
                v.background = rounded(Color.parseColor(t.bg), dp(20))

                val icon = v.findViewById<ImageView>(R.id.tileIcon)
                icon.setImageResource(t.icon)
                icon.imageTintList = ColorStateList.valueOf(Color.WHITE)
                icon.background = oval(Color.parseColor(t.color))
                v.findViewById<TextView>(R.id.tileTitle).setText(t.title)

                v.setOnClickListener { t.action() }
                rowView.addView(v)
            }
        }
    }

    private fun openPrintSettings() {
        try {
            startActivity(Intent(Settings.ACTION_PRINT_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
                toast(getString(R.string.error_open))
            }
        }
    }

    private fun askUrl() {
        val input = EditText(this)
        input.hint = getString(R.string.web_hint)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        input.setSingleLine()
        val box = FrameLayout(this)
        box.setPadding(dp(24), dp(8), dp(24), 0)
        box.addView(
            input,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.web_title)
            .setView(box)
            .setPositiveButton(R.string.open) { _, _ ->
                var url = input.text.toString().trim()
                if (url.isNotEmpty()) {
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        url = "https://$url"
                    }
                    val i = Intent(this, WebPrintActivity::class.java)
                    i.putExtra(WebPrintActivity.EXTRA_URL, url)
                    startActivity(i)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun askLabel() {
        val input = EditText(this)
        input.hint = getString(R.string.label_hint)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.minLines = 2
        val box = FrameLayout(this)
        box.setPadding(dp(24), dp(8), dp(24), 0)
        box.addView(
            input,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.label_title)
            .setView(box)
            .setPositiveButton(R.string.print) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) printLabel(text)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun printLabel(text: String) {
        val safe = TextUtils.htmlEncode(text).replace("\n", "<br>")
        val html = "<html><body style='margin:0'>" +
            "<div style='border:6px solid #000;padding:40px;margin:20px;" +
            "text-align:center;font-family:sans-serif;font-size:56px;font-weight:bold;'>" +
            safe + "</div></body></html>"
        val wv = WebView(this)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (view == null) return
                val title = getString(R.string.tile_labels)
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                pm.print(title, view.createPrintDocumentAdapter(title), PrintAttributes.Builder().build())
            }
        }
        htmlPrintView = wv
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun showEmailHelp() {
        AlertDialog.Builder(this)
            .setTitle(R.string.tile_email)
            .setMessage(R.string.email_help)
            .setPositiveButton(R.string.open_mail) { _, _ ->
                try {
                    startActivity(
                        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_EMAIL)
                    )
                } catch (e: Exception) {
                    toast(getString(R.string.error_open))
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle(R.string.row_connect)
            .setMessage(R.string.help_text)
            .setPositiveButton(R.string.ok, null)
            .show()
    }

    // ------------------------------------------------------------ Scans

    private fun setupScans() {
        findViewById<FloatingActionButton>(R.id.fabScan).setOnClickListener { startScan() }
        refreshScans()
    }

    private fun scansDir(): File {
        val d = File(filesDir, "scans")
        d.mkdirs()
        return d
    }

    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(20)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { toast(getString(R.string.scan_failed)) }
    }

    private fun saveScan(src: Uri) {
        try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val dest = File(scansDir(), "scan_$stamp.pdf")
            contentResolver.openInputStream(src)!!.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
            refreshScans()
            bottomNav.selectedItemId = R.id.nav_scans
            toast(getString(R.string.scan_saved))
        } catch (e: Exception) {
            toast(getString(R.string.scan_failed))
        }
    }

    private fun refreshScans() {
        val files = scansDir().listFiles { f ->
            f.isFile && f.extension.equals("pdf", ignoreCase = true)
        }?.sortedByDescending { it.lastModified() } ?: emptyList()

        scansList.removeAllViews()
        scansEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        scansScroll.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE

        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        for (f in files) {
            val row = layoutInflater.inflate(R.layout.item_scan_row, scansList, false)
            val icon = row.findViewById<ImageView>(R.id.scanIcon)
            icon.imageTintList = ColorStateList.valueOf(Color.WHITE)
            icon.background = rounded(Color.parseColor("#1E9BF0"), dp(12))
            row.findViewById<TextView>(R.id.scanTitle).text =
                getString(R.string.scan_item, df.format(Date(f.lastModified())))
            row.findViewById<TextView>(R.id.scanMeta).text = Formatter.formatFileSize(this, f.length())
            row.setOnClickListener { openPreview(Uri.fromFile(f)) }
            row.findViewById<View>(R.id.scanDelete).setOnClickListener { confirmDelete(f) }
            scansList.addView(row)
        }
    }

    private fun confirmDelete(f: File) {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                f.delete()
                refreshScans()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ------------------------------------------------------------ Settings

    private fun setupSettings() {
        val general = findViewById<LinearLayout>(R.id.generalList)
        val support = findViewById<LinearLayout>(R.id.supportList)

        addSettingRow(general, R.drawable.ic_help, "#4F7CF0", getString(R.string.row_connect)) {
            showHelp()
        }
        addSettingRow(general, R.drawable.ic_star, "#F5B50B", getString(R.string.row_rate)) {
            rateApp()
        }
        addSettingRow(general, R.drawable.ic_share, "#16A34A", getString(R.string.row_share)) {
            shareApp()
        }

        addSettingRow(support, R.drawable.ic_shield, "#EF4444", getString(R.string.row_privacy)) {
            showPrivacy()
        }
        addSettingRow(support, R.drawable.ic_chat, "#F97316", getString(R.string.row_feedback)) {
            sendFeedback()
        }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.versionText).text = getString(R.string.version_fmt, version)
    }

    private fun addSettingRow(
        parent: LinearLayout,
        icon: Int,
        color: String,
        title: String,
        subtitle: String? = null,
        onClick: () -> Unit
    ) {
        val row = layoutInflater.inflate(R.layout.item_setting_row, parent, false)
        val iv = row.findViewById<ImageView>(R.id.rowIcon)
        iv.setImageResource(icon)
        iv.imageTintList = ColorStateList.valueOf(Color.WHITE)
        iv.background = rounded(Color.parseColor(color), dp(12))
        row.findViewById<TextView>(R.id.rowTitle).text = title
        if (subtitle != null) {
            val sub = row.findViewById<TextView>(R.id.rowSubtitle)
            sub.text = subtitle
            sub.visibility = View.VISIBLE
        }
        row.setOnClickListener { onClick() }
        parent.addView(row)
    }

    private fun rateApp() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                    )
                )
            } catch (e2: Exception) {
                toast(getString(R.string.error_open))
            }
        }
    }

    private fun shareApp() {
        val link = "https://play.google.com/store/apps/details?id=$packageName"
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_text, link))
        startActivity(Intent.createChooser(i, null))
    }

    private fun showPrivacy() {
        if (AppConfig.PRIVACY_URL.isNotBlank()) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.PRIVACY_URL)))
            } catch (e: Exception) {
                toast(getString(R.string.error_open))
            }
        } else {
            AlertDialog.Builder(this)
                .setTitle(R.string.row_privacy)
                .setMessage(R.string.privacy_text)
                .setPositiveButton(R.string.ok, null)
                .show()
        }
    }

    private fun sendFeedback() {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
        i.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast(getString(R.string.error_open))
        }
    }

    // ---------------------------------------------------------------- Helpers

    private fun openPreview(uri: Uri) {
        val i = Intent(this, PreviewActivity::class.java)
        i.action = Intent.ACTION_VIEW
        i.data = uri
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(i)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius.toFloat()
        return d
    }

    private fun oval(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        return d
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
