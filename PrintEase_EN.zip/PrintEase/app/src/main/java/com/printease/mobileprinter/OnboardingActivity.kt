package com.printease.mobileprinter

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class OnboardingActivity : AppCompatActivity() {

    private data class Page(val icon: Int, val title: Int, val text: Int)

    private val pages = listOf(
        Page(R.drawable.ic_printer, R.string.ob1_title, R.string.ob1_text),
        Page(R.drawable.ic_wifi, R.string.ob2_title, R.string.ob2_text),
        Page(R.drawable.ic_scan, R.string.ob3_title, R.string.ob3_text)
    )
    private var index = 0

    private lateinit var icon: ImageView
    private lateinit var titleView: TextView
    private lateinit var textView: TextView
    private lateinit var dots: LinearLayout
    private lateinit var next: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        icon = findViewById(R.id.obIcon)
        titleView = findViewById(R.id.obTitle)
        textView = findViewById(R.id.obText)
        dots = findViewById(R.id.obDots)
        next = findViewById(R.id.btnNext)

        icon.background = GradientDrawable().apply {
            setColor(getColor(R.color.primary))
            cornerRadius = dp(48).toFloat()
        }

        next.setOnClickListener {
            if (index < pages.lastIndex) {
                index++
                render()
            } else {
                finishOnboarding()
            }
        }
        findViewById<View>(R.id.btnSkip).setOnClickListener { finishOnboarding() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (index > 0) {
                    index--
                    render()
                } else {
                    finish()
                }
            }
        })

        render()
    }

    private fun render() {
        val p = pages[index]
        icon.setImageResource(p.icon)
        icon.imageTintList = ColorStateList.valueOf(Color.WHITE)
        titleView.setText(p.title)
        textView.setText(p.text)
        next.setText(if (index == pages.lastIndex) R.string.start else R.string.next)

        dots.removeAllViews()
        for (i in pages.indices) {
            val size = if (i == index) dp(24) else dp(8)
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                setColor(if (i == index) getColor(R.color.primary) else Color.parseColor("#C9D3E0"))
                cornerRadius = dp(4).toFloat()
            }
            val lp = LinearLayout.LayoutParams(size, dp(8))
            lp.marginStart = dp(4)
            lp.marginEnd = dp(4)
            dots.addView(dot, lp)
        }
    }

    private fun finishOnboarding() {
        getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE)
            .edit().putBoolean(AppConfig.KEY_ONBOARDING_DONE, true).apply()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
