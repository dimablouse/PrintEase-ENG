package com.printease.mobileprinter

import android.annotation.SuppressLint
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class WebPrintActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "url"
    }

    private lateinit var webView: WebView
    private lateinit var pageTitle: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_print)

        webView = findViewById(R.id.webView)
        pageTitle = findViewById(R.id.pageTitle)

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageTitle.text = view?.title ?: url ?: ""
            }
        }

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnPrint).setOnClickListener {
            val title = webView.title ?: getString(R.string.app_name)
            val pm = getSystemService(PRINT_SERVICE) as PrintManager
            pm.print(title, webView.createPrintDocumentAdapter(title), PrintAttributes.Builder().build())
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        webView.loadUrl(intent.getStringExtra(EXTRA_URL) ?: "about:blank")
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
