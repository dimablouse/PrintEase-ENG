package com.printease.mobileprinter

/** Settings to replace before publishing. */
object AppConfig {
    const val SUPPORT_EMAIL = "support@example.com"

    /** Privacy policy link. If empty, a short text is shown in a dialog. */
    const val PRIVACY_URL = ""

    const val PREFS = "printease"
    const val KEY_ONBOARDING_DONE = "onboarding_done"
}
